package assas;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import utils.StdOut;

public class Test {

	public static void main(String[] args)  throws Exception
	{
		AssasBand assas = new AssasBand();
		String stem="";
		stem = assas.applyStemming("چیرتی");
		System.out.println(stem);
		
		stem = assas.applyStemming("مائیکروسافٹ");
		System.out.println(stem);
		
		stem = assas.applyStemming("کمپیوٹر");
		System.out.println(stem);
		
		
		stem = assas.applyStemming("کراچی");
		System.out.println(stem);
		
		stem = assas.applyStemming("تو");
		System.out.println(stem);
		
		stem = assas.applyStemming("ت#");
		System.out.println(stem);
		
		stem = assas.applyStemming("جانا");
		System.out.println(stem);
		/*
		String input = "input.txt";
		String output = "output.txt";
		
		String encoding = "UTF-8";
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(input), encoding));;
		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(output), encoding));

		assas = new AssasBand();
		int count = 0;
		for (String line; (line = reader.readLine()) != null;) 
		{
			line = line.trim();
			if (line.length()==0) continue;
			String toks[] = line.split("[ \t]+");//\\s

			for(int i=0; i<toks.length;i++)
			{
				
				if ((toks.length-1)==i)
				{			
					writer.write(assas.applyStemming(toks[i]));
					writer.newLine();
					continue;
				}
			
				writer.write(assas.applyStemming(toks[i])+" ");
			}
			StdOut.println("Line "+(++count) +" is written...");
		}			
		if (writer!=null) {
			writer.flush();
			writer.close();
		}
		if (reader!=null) reader.close();
		StdOut.println("Task finished...");
	*/
		
		
	}

}
