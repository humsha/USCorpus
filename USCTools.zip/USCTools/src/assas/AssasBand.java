package assas;
import java.awt.List;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.print.DocFlavor.STRING;
import javax.swing.JOptionPane;

import utils.StdOut;

public class AssasBand {

	ArrayList<String> Prefixs;
	ArrayList<String> Postfixs;
	ArrayList<String> PoGEL;
	ArrayList<String> PrGEL;
	Hashtable PoREL;
	Hashtable ACL;
	public AssasBand()
	{
		this.Prefixs = this.setPrefixs();
		this.Postfixs = this.setPostfixs();
		this.PrGEL = this.setPrGEL();
		this.PoGEL = this.setPoGEL();
		this.PoREL = this.setPoREL();
		this.ACL = this.setACL();
		
	}//end of constructor
	
	public String applyStemming(String input)
	{
		//Removing Prefix from input
		if(!this.PrGEL.contains(input))
			input = this.removePrefix(input);
		//System.out.println("Prefix Passed");
		//Removing Postfix from stem
		if(!PoGEL.contains(input))
		{
			String rules[] = this.getMatchingPostfixs(input);
			String str = "";
			for(int i=0; i<rules.length; i++)
			{
				str = String.valueOf(this.PoREL.get(rules[i]));
				String b[] = str.split(":");
				if(!this.isPostfixExceptionExist(b, input))
				{
					input = input.substring(0,(input.length()-rules[i].length()));
					break;
				}
			}//end of for loop
		}//end of postfix removing
		//System.out.println("Postfix Passed");
		//Add Character
		String list[] = {"ا","ت","ہ","ی","یہ"};
		String str = "";
		for(int i=0; i<list.length; i++)
		{
			str = String.valueOf(this.ACL.get(list[i]));
			String b[] = str.split(":");
			if(this.isPostfixExceptionExist(b, input))
			{
				input = input+list[i];
				break;
			}
		}//end of for loop
		
		return input;
	}//end of applyAssasBandAlgorithm
	
	public ArrayList<String> setPrefixs()
	{
		OperationsForDataPreparation obj = new OperationsForDataPreparation();
		return obj.readFile("stemmingfiles/Prefixs.txt");
	}
	
	public ArrayList<String> setPostfixs()
	{
		OperationsForDataPreparation obj = new OperationsForDataPreparation();
		return obj.readFile("stemmingfiles/Postfixs.txt");
	}
	
	public ArrayList<String> setPoGEL()
	{
		OperationsForDataPreparation obj = new OperationsForDataPreparation();
		return obj.readFile("stemmingfiles/PoGEL.txt");
	}
	
	public ArrayList<String> setPrGEL()
	{
		OperationsForDataPreparation obj = new OperationsForDataPreparation();
		return obj.readFile("stemmingfiles/PrGEL.txt");
	}
	
	public Hashtable setACL()
	{
		OperationsForDataPreparation obj = new OperationsForDataPreparation();
		ArrayList<String> list = obj.readFile("stemmingfiles/ACL.txt");
		String str = "", key = "";
		Hashtable hashList = new Hashtable();
		for(int i=1; i<list.size(); i++)
		{
			str = list.get(i);//Need to set i
			if(str.contains(":"))
			{
				String b[] = str.split(":");
				key = b[b.length-1];
				str = str.substring(0,(str.length()-b[b.length-1].length()-1));//1 extra for last delimeter
				hashList.put(key, str);
			}
			else
			{
				hashList.put(str, "No Word");
			}
		}//end of for loop
		return hashList;
	}//end of setREL()
	
	public Hashtable setPoREL()
	{
		OperationsForDataPreparation obj = new OperationsForDataPreparation();
		ArrayList<String> list = obj.readFile("stemmingfiles/PoREL.txt");
		String str = "", key = "";
		Hashtable hashList = new Hashtable();
		for(int i=1; i<list.size(); i++)
		{
			str = list.get(i);//Need to set i
			if(str.contains(":"))
			{
				String b[] = str.split(":");
				key = b[b.length-1];
				str = str.substring(0,(str.length()-b[b.length-1].length()-1));//1 extra for last delimeter
				hashList.put(key, str);
			}
			else
			{
				hashList.put(str, "No Word");
			}
		}//end of for loop
		return hashList;
	}//end of setREL()
	
	public String removePrefix(String input)
	{
		int index = 1;
		String str = String.valueOf(input.charAt(0));
		while(index<input.length())
		{
			//System.out.println("index: "+index+"\t\t"+str);
			if(this.isContainPrefixMatch(str))
			{
				str = str+input.charAt(index);
				index++;
			}
			else
				break;
		}//end of while
		
		if(index>1)
		{
			while(str.length()>0)
			{
				index--;
				str = str.substring(0,index);
				if(this.isEqualPrefix(str))
					return input.substring(str.length(),input.length());
				if(index==1)
					return input;
			}//end of while
		}
		return input;
	}//end of removePrefix()
	
	public boolean isContainPrefixMatch(String input)
	{
		for(int i=0; i<this.Prefixs.size(); i++)
			if(this.Prefixs.get(i).startsWith(input))
				return true;
		return false;
	}//end of isContainPrefixMatch()
	
	public boolean isEqualPrefix(String input)
	{
		if(this.Prefixs.contains(input))
			return true;
		else
			return false;
	}//end of isEqualPrefixMatch()

	public String[] getMatchingPostfixs(String input)
	{
		ArrayList<String> list = new ArrayList<String>();
		for(int i=0; i<this.Postfixs.size(); i++)
			if(input.endsWith(this.Postfixs.get(i)))
				list.add(this.Postfixs.get(i));
		
		//Converting List to array
		String array[] = new String[list.size()];
		for(int i=0; i<array.length; i++)
			array[i] = list.get(i);
		
		//Sorting
		int len = 0, len2 = 0;
		String str = "";
		for(int i=0; i<array.length; i++)
		{
			len = array[i].length();
			for(int j=i+1; j<array.length; j++)
			{
				len2 = array[j].length();
				if(len<len2)
				{
					str = array[i];
					array[i] = array[j];
					array[j] = str;
				}
			}
		}
		return array;
	}//end of getMatchingPostfixs
	
	public boolean isPostfixExceptionExist(String array[], String key)
	{
		for(int i=0; i<array.length; i++)
			if(key.equals(array[i]))
				return true;
		return false;
	}//end of isPostfixExceptionExist()
	
}//end of class
