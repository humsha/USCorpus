package assas;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class FileHandler {
	
	Scanner s, s2;
	String s3;
	
	public void Write_Data(String file_name, String str, boolean mode){

	  	try
	  	{
	  			FileWriter fw = new FileWriter(file_name,mode);
	  			BufferedWriter bf = new BufferedWriter(fw);
	  			if(mode)
	  				bf.newLine();
	  			bf.write(str);
	  			bf.close();
	  		
	  	}catch(IOException r){}
	  	
	  }//end of method

 
 public String[] getPrefixes()
 {
	 int len = getRowCountr("Prefixs.txt");
	 String list[] = new String[len];
	 try
	 {
 		FileReader f2 = new FileReader("Prefixs.txt");
 		s2 = new Scanner(f2);
 		int i = len-1;
 		while(s2.hasNext())
 		{
 			list[i] = s2.next();
 			i--;
 		}
 		
 		return list;
 }
 catch(IOException e){}
 return new String[1];
 }
 
 public int getRowCountr(String filename)
 {
 try
 {
 		FileReader f2 = new FileReader(filename);
 		s2 = new Scanner(f2);
 		s3 = "";
 		int i = 0;
 		while(s2.hasNext())
 		{
 			s3 = s2.next();
 			i++;
 		}
 		return i;
 }
 catch(IOException e){}
 return 0;
 }
 
 
 public String[] getPostfixes()
 {
	 int len = getRowCountr("Postfixs.txt");
	 String list[] = new String[len];
	 try
	 {
 		FileReader f2 = new FileReader("Postfixs.txt");
 		s2 = new Scanner(f2);
 		int i = 0;
 		while(s2.hasNext())
 		{
 			list[i] = s2.next();
 			i++;
 		}
 		
 		return list;
 }
 catch(IOException e){}
 return new String[1];
 }
 
 
 
 
}//end of class
