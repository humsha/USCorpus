package assas;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;


public class OperationsForDataPreparation {

	public int countExistenceOfKey(String fileName,String key)
	{
		int counter = 0;
		String str = "", str2 = "";
		try
		{
			FileReader f = new FileReader(fileName);
			Scanner s = new Scanner(f);
			while(s.hasNext())
			{
				str = s.nextLine();
				if(str.contains(key))
				{
					counter++;
					System.out.println(str);
				}
			}//end of while		
		}
		catch(IOException e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return counter;
	}//end of method
	
	public ArrayList<String> readFile(String fileName)
	{
		ArrayList<String> list = new ArrayList<String>();
		String str = "";
		try
		{
			FileReader f = new FileReader(fileName);
			Scanner s = new Scanner(f);
			while(s.hasNext())
			{
				str = s.nextLine();
				list.add(str);
			}//end of while		
		}
		catch(IOException e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return list;
	}//end of method
	
	public void makeFileOfUniqueWords1WPL(String fileName)
	{
		ArrayList<String> list = new ArrayList<String>();
		ArrayList<String> list2 = new ArrayList<String>();
		list = this.readFile(fileName);
		for(int i=0; i<list.size(); i++)
		{
			if(!list2.contains(list.get(i)))
				list2.add(list.get(i));
		}//end of for loop
		FileHandler fh = new FileHandler();
		for(int i=0; i<list2.size(); i++)
		{
			if(i==0)
				fh.Write_Data(fileName, list2.get(i), false);
			else
				fh.Write_Data(fileName, list2.get(i), true);
		}//end of for loop
		
	}//end of method
	
	public void makeFileOfUniqueWordsMWPL(String fileName, String delimeter)
	{
		ArrayList<String> list = this.readFile(fileName);
		ArrayList<String> list2 = new ArrayList<String>();
		ArrayList<String> list3 = new ArrayList<String>();
		String str = "", str2 = "";
		System.out.println(list.size());
		for(int i=1; i<list.size(); i++)
		{
			str = list.get(i);
			String b[] = str.split(delimeter);
			for(int j=0; j<b.length-1; j++)
				if(!list2.contains(b[j]))
					list2.add(b[j]);
			str2 = "";
			for(int j=0; j<list2.size(); j++)
				str2 = str2+delimeter+list2.get(j);
			str2 = str2+delimeter+b[b.length-1];
			str2 = str2.substring(1,str2.length());
			list3.add(str2);
			list2.clear();
		}//end of for loop
		
		FileHandler fh = new FileHandler();
		fh.Write_Data(fileName, "", false);
		for(int i=0; i<list3.size(); i++)
		{
			fh.Write_Data(fileName, list3.get(i), true);
		}//end of for loop
		
	}//end of method
	
	public void displayValuesBetweenKey(String sourceName, String targetFile, String key, String delimeter, ArrayList<String> list)
	{
		int counter = 0, counter2 = 0;
		String str = "", str2 = "", str3 = "";
		FileHandler fh = new FileHandler();
		boolean check = false;
		try
		{
			FileReader f = new FileReader(sourceName);
			Scanner s = new Scanner(f);
			while(s.hasNext())
			{
				str = s.nextLine();
				if(str.contains(key) && check)	
				{
					str3 = str2+delimeter+list.get(counter);
					str3 = str3.substring(1,str3.length());
					fh.Write_Data(targetFile, str3, true);
					str2 = "";
					counter++;
				}
				else
				{
					if(check)
						str2 = str2+delimeter+str;
					check = true;
				}
				counter2++;
			}//end of while
			str3 = str2+delimeter+list.get(counter);
			str3 = str3.substring(1,str3.length());
			fh.Write_Data(targetFile, str3, true);
		}
		catch(IOException e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		System.out.println("Processing finished: "+counter);
		System.out.println("Total Processed Lines: "+counter2);
	}//end of method
	
}//end of class

	//These five lines can be used when we will update files 
	/*	ArrayList<String> acl = new OperationsForDataPreparation().readFile("ACL2.txt");
		new OperationsForDataPreparation().displayValuesBetweenKey("ACL1.txt", "ACL.txt", "<", ":", acl);
		System.out.println(new OperationsForDataPreparation().countExistenceOfKey("PoREL1.txt", "<"));
		ArrayList<String> porel = new OperationsForDataPreparation().readFile("PoREL2.txt");
		new OperationsForDataPreparation().displayValuesBetweenKey("PoREL1.txt", "PoREL.txt", "<", ":", porel);
		
		*/
