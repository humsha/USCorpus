package utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;


public class Preprocessing {

	private String originaltext;
	private String processedtext;

	private String[] replace;
	private String[] find;

	public Preprocessing(String text, boolean diacreticmark, boolean normalization) throws Exception {
		originaltext = text;
		assignationation();
		
		if (normalization) {
			processedtext = normalization_NFC(originaltext, " ");
		}
		
		if (diacreticmark) {
			processedtext = diacreticMarksremovall(processedtext);
		}
		
	}
	
	
	public String getProcessedtext() {
		return processedtext;
	}

	public String getOriginaltext() {
		return originaltext;
	}


	private String diacreticMarksremovall(String str) {
		String arab[] = { "ٰ", "َ", "ِ", "ُ", "ّ", "ً", "ٍ", "ْ" };
		str = str.replaceAll(arab[0], "-");
		str = str.replaceAll(arab[1], "-");
		str = str.replaceAll(arab[2], "-");
		str = str.replaceAll(arab[3], "-");
		str = str.replaceAll(arab[4], "-");
		str = str.replaceAll(arab[5], "-");
		str = str.replaceAll(arab[6], "-");
		str = str.replaceAll(arab[7], "-");
		String b[] = str.split("-");
		str = "";
		for (int i = 0; i < b.length; i++)
			str = str + b[i];

		return str;
	}

	private void assignationation() {
		String str = readRules();
		//System.out.println("str: "+str);
		String[] aa = str.split("\n");
		
		String[] array = new String[aa.length];
		String[] swapper = new String[aa.length];
		for (int i = 0; i < aa.length; i++) 
		{
			String[] wsplit = aa[i].split(":");
			array[i] = wsplit[0];
			swapper[i] = wsplit[1];
			//System.out.println(aa[i]);
			//System.out.println("array:"+array[i]+" swapper:"+swapper[i]);
		}
		
		this.replace = swapper;
		this.find = array;
	}

	private String[] replacers() {
		return this.replace;

	}

	private String[] find_it() {
		return this.find;

	}

	private String readRules() {
		StringBuffer buffer = new StringBuffer();
		try {
			FileInputStream fis = new FileInputStream("data/normalizeNFC.txt");
			InputStreamReader isr = new InputStreamReader(fis, "UTF16");
			Reader in = new BufferedReader(isr);
			int ch;
			while ((ch = in.read()) > -1) {
				buffer.append((char) ch);

			}
			in.close();
			return buffer.toString();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	private String normalization_NFC(String data, String delim) {

		String[] totaldata = data.split("["+delim+"]+");
		for (int i = 0; i < totaldata.length; i++) {

			for (int j = 0; j < this.find_it().length; j++) {

				totaldata[i] = totaldata[i].replaceAll(find_it()[j],
						replacers()[j]);
			}
		}
		String data1 = "";
		for (int i = 0; i < totaldata.length; i++) {
			data1 += totaldata[i] + delim;
		}
		return data1;
	}

	
	public static void main(String args[]) throws Exception {

		String string = "الطاف حسین بیس سال سے انگلینڈ میں پرتعیش سٹائل کے حصار میں ایک خوفناک پاکستانی سیاست چلا رہے ہیں اور وہاں وہ پاکستانی قانون کی پہنچ سے دور ہیں ۔";
		Preprocessing p = new Preprocessing(string, true, true);
		System.out.println(p.getOriginaltext() + "\n" + p.getProcessedtext());
	}

}
