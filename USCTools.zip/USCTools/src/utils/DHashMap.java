package utils;
import java.util.*;


public class DHashMap<T,E> extends HashMap<String, ArrayList<String>> {

	private static final long serialVersionUID = 2414742741167570676L;

	public void put(String key, String val) {
		ArrayList<String> current = get(key);
        if (current == null) {
            current = new ArrayList<String>();
            super.put(key, current);
        }
        current.add(val);
	} 
	
	public String printVal(ArrayList<String> val)
	{	
		String output="";
		if (val.size()==0) return null;
		for(int i=0; i<val.size(); i++)
		{	
			String v = val.get(i);
			if (i==0) 
				output = v ;
			else 
				output = output +"\n\t"+ v ;
		}
		return output;
	}
	
	public static void main(String args[]) {
		
		DHashMap<String, ArrayList<String>> m = new DHashMap<String, ArrayList<String>>();
		m.put("a", "1");
		m.put("a", "2");
		m.put("b", "3");
		for(Map.Entry e : m.entrySet()) {
			System.out.println(e.getKey() + " -> " + m.printVal((ArrayList<String>) e.getValue()));
		}
		
		
	}
	
	
	

	
	
}
