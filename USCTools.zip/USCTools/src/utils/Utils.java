package utils;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

/**
 *  @author Muhammad Humayoun <humayoun@gmail.com>
 */

public class Utils {
	
	public String read_as_string(String file) throws FileNotFoundException {
	    BufferedReader reader = null;
	    StringBuilder builder = new StringBuilder();
	    try {
	    	reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
	    	String text = "";
	      
	        while((text = reader.readLine()) != null) {
	            builder.append(text);
	            builder.append("\n");
	        }
	    } catch(IOException ex) {
	    	
	        ex.printStackTrace();
	    } 
	    finally {
	        try {
	            if (reader != null)
	            	{
	            	reader.close();
	            	
	            	}
	        } catch (IOException ex) {
	            ex.printStackTrace();
	        }
	    }
	    return builder.toString();
	}

	public ArrayList<String> read_as_list(String file) throws FileNotFoundException {
	    BufferedReader reader = null;
	    ArrayList<String> lines = new ArrayList<String>();

		try {
	    	reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
	    	String text = "";
	      
	        while((text = reader.readLine()) != null) {
	            lines.add(text);
	        }
	    } catch(IOException ex) {
	    	
	        ex.printStackTrace();
	    } 
	    finally {
	        try {
	            if (reader != null)
	            	{
	            	reader.close();
	            	
	            	}
	        } catch (IOException ex) {
	            ex.printStackTrace();
	        }
	    }
	    return lines;
	}

	//this function removed duplicate words from a wordlist containing one word per line
	public void remove_duplicate_words(String inputfile, String outputfile) throws Exception
	{
		StringBuilder sb = new StringBuilder();
		BufferedWriter w = new BufferedWriter(new FileWriter(outputfile));
		
		String s = read_as_string(inputfile);
		String delim = System.getProperty("line.separator");
		HashMap<String, Integer> map = makeWordList(s, delim);
		Map<String, Integer> sortedmap = new TreeMap<String, Integer>(Collections.reverseOrder());
		sortedmap = sortByValues(map);
		
		 for (String key : sortedmap.keySet()) 
		 {
			 //key is word
			 if ((key.length()!=1))
			 {
				 System.out.println(key+" , "+ sortedmap.get(key));
				 w.write(key.trim());
				 w.newLine();
			 }
		 }
		 if (w!=null){
			 w.flush();
			 w.close();			 
		 }
	}
	
	public static HashMap<String, Integer> makeWordList(String s, String delim){
        Scanner scan = new Scanner(s);
    	scan.useDelimiter(delim);
    	HashMap<String, Integer> listOfWords = new HashMap<String, Integer>();
        while(scan.hasNext())
        {
            String word = scan.next(); //scanner automatically uses "#" as a delimeter
            int countWord = 0;
            if(!listOfWords.containsKey(word))
            {                             //add word if it isn't added already
                listOfWords.put(word, 1); //first occurance of this word
            }
            else
            {
                countWord = listOfWords.get(word) + 1; //get current count and increment
                //now put the new value back in the HashMap
                listOfWords.remove(word); //first remove it (can't have duplicate keys)
                listOfWords.put(word, countWord); //now put it back with new value
            }
        }
        scan.close();
        return listOfWords; //return the HashMap you made of distinct words
    }
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static HashMap<String, Integer> sortByValues(HashMap<String, Integer> map) { 
		LinkedList<HashMap<String, Integer>> list = new LinkedList(map.entrySet());
	       // Defined Custom Comparator here
	       Collections.sort(list, new Comparator() {
	            public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o2)).getValue())
	                  .compareTo(((Map.Entry) (o1)).getValue());
	            }
	       });
	       // Here I am copying the sorted list in HashMap
	       // using LinkedHashMap to preserve the insertion order
	       HashMap sortedHashMap = new LinkedHashMap();
	       for (Iterator it = list.iterator(); it.hasNext();) {
	              Map.Entry entry = (Map.Entry) it.next();
	              sortedHashMap.put(entry.getKey(), entry.getValue());
	       } 
	       return sortedHashMap;
	  }
	
	
	

}
