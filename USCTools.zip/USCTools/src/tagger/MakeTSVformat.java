package tagger;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Random;


import utils.Preprocessing;
import utils.StdOut;

public class MakeTSVformat {

	public static void main(String[] args) throws Exception{
		
		
		String encoding = "UTF-8";
		int count=0;
		//Total lines in file: 5464575
		int ninety_percent = 4918118; 	//4918118	90%
		int eighty_percent = 4371660; 	//4371660	80%
		int seventy_percent =3825203; 	//3825203	70%
		int twenty_percent = 1092915;  	//1092915	20%
		int thirty_percent = 1639373; 	//1639373	30%
		int ten_percent = 546458; 	 	//546458	10
		int five_percent = 273229; 	 	//05%
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("data/urmono.tag"), encoding));
		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("data/urmono.tag.tsv"), encoding));

		int counter=0;
		StdOut.println("Task started...");
		for (String line; (line = reader.readLine()) != null;) 
		{
			if (line.length()==0) continue;
			
			
			String wts[] = line.split("\\s+");
			for (String wt: wts)
			{
				String wordtag[]= wt.split("\\|");
				if (wordtag.length<=1 ) continue;
				
				writer.write(wordtag[0]+"\t"+wordtag[1]);
				writer.newLine();
			}
			writer.newLine();
			
			if (counter++>five_percent) break;
			//StdOut.println("Line "+(++count) +" is written...");
			for(int i=0;i<9;i++){ reader.readLine(); }
		}	
		StdOut.println("Total Lines "+ counter);
		
		if (writer!=null) {
			writer.flush();
			writer.close();
		}
		if (reader!=null) reader.close();
		StdOut.println("Task finished...");
		
	}

}


