package tagger;

public class Bigram_Tags {
	private String tag1;
	private String tag2;
	//double freq=0;
	public Bigram_Tags(String t1, String t2)//, double f)
	{
		tag1 = t1;
		tag2 = t2;
		//freq = f;
	}
	
	public String getTag1() {
		return tag1;
	}
	public void setTag1(String tag1) {
		this.tag1 = tag1;
	}
	public String getTag2() {
		return tag2;
	}
	public void setTag2(String tag2) {
		this.tag2 = tag2;
	}
	
	//public double getFreq() {
		//return freq;
	//}
	
}
