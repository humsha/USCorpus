package tagger;

import java.util.HashMap;

import utils.StdOut;

public class TestTagger {

	public static void main(String[] args) throws Exception{

		POS_tagger pos = new POS_tagger();
		
		HashMap<String, String> dict1 = pos.initialize_unigram("data/unigram_stats.txt");
		HashMap<String, Bigram_Tags> dict2 = pos.initialize_bigram("data/bigram_stats.txt", 200000);
		
		String line = "روس کے صدر ولادی میر پوتن نے ترکی کی جانب سے روسی جہاز گرائے جانے پر ترکی کے رہنماؤں کو کڑی تنقید کا نشانہ بنایا ہے";
		if (line.length()==0) System.exit(1);
	
		String toks[] = line.split("[ ]+");//\\s
		for(int i=0; i<toks.length;i++)
		{
			for(int j=i+1; j<toks.length;)
			{
				String w1 = toks[i];
				String w2 = toks[j];
				String bi = w1+w2;

				Bigram_Tags bt = dict2.get(bi);
				if (bt==null) 
				{
					String ut = dict1.get(w1);
					if (ut==null)
						StdOut.print(w1+"|UNK ");
					else 
						StdOut.print(w1+"|"+ut+" ");


				}
				else 
				{
					StdOut.print(w1+"|"+bt.getTag1()+" ");
				}

				break;
			}
			if((toks.length-1)==i) 
			{
				String w1 = toks[i];
				if (w1.equals("۔") || w1.equals("؟")||w1.equals(":") ) 
					StdOut.print(w1+"|SM"); 
				else 
				{
					String ut = dict1.get(w1);
					if (ut==null)
						StdOut.print(w1+"|UNK");
					else 
						StdOut.print(w1+"|"+ut);
				}
				StdOut.println();
			}
		}

	}
	
	
	

}
