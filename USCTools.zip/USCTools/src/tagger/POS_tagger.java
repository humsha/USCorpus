package tagger;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import utils.StdOut;

public class POS_tagger {


	public static void main(String[] args) throws Exception
	{
		POS_tagger pos = new POS_tagger();
		HashMap<String, String> dict1 = pos.initialize_unigram("data/unigram_stats.txt");
		HashMap<String, Bigram_Tags> dict2 = pos.initialize_bigram("data/bigram_stats.txt", 100000);
		
	
		
	}
	
	public HashMap<String, String> initialize_unigram(String file) throws Exception
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
		HashMap<String, String> uni_dict = new HashMap<String, String>();

		String line=""; int count=1;
		while((line = reader.readLine()) != null)
		{
			String toks[] = line.split("::");
			if (toks.length == 0) continue;
			
			String []wt1 = toks[0].split("\\|");
			
			if (wt1.length == 0) continue;
			
			//this is a hack. dictionary is sorted w.r.t freq. 
			//So the highest freq word is on top. So if it is 
			//in the map don't add other tags (having less freq) for this word 
			if(uni_dict.containsKey(wt1[0])) continue;
				
			uni_dict.put(wt1[0], wt1[1]);
			
		}
		if (reader != null) reader.close();
	            	
	   // StdOut.println(uni_dict.size());
	    
	    return uni_dict;
	}
	
	public HashMap<String, Bigram_Tags> initialize_bigram(String file, int max) throws Exception
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
		HashMap<String, Bigram_Tags> bi_dict = new HashMap<String, Bigram_Tags>();

		String line=""; int count=1;
		while((line = reader.readLine()) != null)
		{
			String toks[] = line.split("::");
			if (toks.length == 0) continue;
			
			String text[] = toks[0].split(" ");
			if (text.length == 0) continue;
			
			String []wt1 = text[0].split("\\|");
			String []wt2 = text[1].split("\\|");
			
			if (wt1.length == 0) continue;
			if (wt2.length == 0) continue;
			
			//Double f = new Double(toks[1].trim());
			Bigram_Tags bt = new Bigram_Tags(wt1[1], wt2[1]); //,f.doubleValue()
			
			//this is a hack. dictionary is sorted w.r.t freq. 
			//So the highest freq word is on top. So if it is 
			//in the map don't add other tags (having less freq) for this word 
			if(bi_dict.containsKey(wt1[0]+wt2[0])) continue;
			
			bi_dict.put(wt1[0]+wt2[0], bt);
			if (count++>=max) break;
			
		}
		if (reader != null) reader.close();
	            	
	    //StdOut.println(bi_dict.size());
	    
	    return bi_dict;
	}

}
