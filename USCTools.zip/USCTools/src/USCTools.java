import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;

import assas.AssasBand;
import tagger.Bigram_Tags;
import tagger.POS_tagger;
import utils.DHashMap;
import utils.Preprocessing;
import utils.StdOut;
import lemmatization.*;

/**
 *  @author Muhammad Humayoun <humayoun@gmail.com>
 */

public class USCTools {
	private static String err_message="					   \n"
			+ "Available commands...\n"
			+ "$ java -cp bin USCTools normalize input.txt output.txt \t //for Normaization\n"
			+ "$ java -cp bin USCTools lemmatize input.txt output.txt \t //for Lemmatization\n"
			+ "$ java -cp bin USCTools morph_analysis input.txt output.txt \t //for Morphological analysis\n"
			+ "$ java -cp bin USCTools stemming input.txt output.txt \t //for stemming by Assas-Band\n"
			+ "$ java -cp bin USCTools tagging input.txt output.txt \t //for POS tagging" ;
	
	
	public static void main(String[] args) throws Exception{
		
		if ((args.length!=3) || (args[0].equalsIgnoreCase("help")))
		{
			StdOut.println(err_message);
			System.exit(0);
		}

		String command = args[0];
		String input = args[1];
		String output = args[2];
		
		String encoding = "UTF-8";
		String humayoun_dic = "data/urdu_unicode.fullform.txt";
		
		File oFile = new File(output);
		if(!oFile.exists()) {
		    oFile.createNewFile();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(input), encoding));;
		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(output), encoding));
		
		if (command.equalsIgnoreCase("normalize"))
		{
			int count=0;
			for (String line; (line = reader.readLine()) != null;) 
			{
				if (line.length()==0) continue;
				
				Preprocessing p = new Preprocessing(line, true, true);
				writer.write(p.getProcessedtext());
				writer.newLine();
				StdOut.println("Line "+(++count) +" is written...");
			}			
			if (writer!=null) {
				writer.flush();
				writer.close();
			}
			if (reader!=null) reader.close();
			StdOut.println("Task finished...");
			
		}
		else if (command.equalsIgnoreCase("lemmatize"))
		{
			Humayoun_Lemmatizer hum = new Humayoun_Lemmatizer();
			HashMap<String, String> lemma_dict = hum.initialize_dict_lemma(humayoun_dic);
			int count = 0;
			for (String line; (line = reader.readLine()) != null;) 
			{
				if (line.length()==0) continue;
				String toks[] = line.split("[ \t]+");//\\s
				for(int i=0; i<toks.length;i++)
				{
					if ((toks.length-1)==i)
					{
						if (lemma_dict.get(toks[i])==null)	writer.write(toks[i]);
						else writer.write(lemma_dict.get(toks[i]));
						
						writer.newLine();
						continue;
					}
					
					if (lemma_dict.get(toks[i])==null) writer.write(toks[i]+" ");
					else writer.write(lemma_dict.get(toks[i])+" ");
					
				}
				StdOut.println("Line "+(++count) +" is written...");
			}			
			if (writer!=null) {
				writer.flush();
				writer.close();
			}
			if (reader!=null) reader.close();
			StdOut.println("Task finished...");
			
			
		}
		else if (command.equalsIgnoreCase("morph_analysis"))
		{
			Humayoun_Lemmatizer hum = new Humayoun_Lemmatizer();
			DHashMap<String, String> ma_dict = hum.initialize_MA(humayoun_dic);
			
			int count = 0;
			for (String line; (line = reader.readLine()) != null;) 
			{
				if (line.length()==0) continue;
				String toks[] = line.split("[ \t]+");//\\s
				for(int i=0; i<toks.length;i++)
				{
					if (ma_dict.get(toks[i])==null)	
						writer.write(toks[i]+"\t"+toks[i]+" UNK");
					else 
						writer.write(toks[i]+"\t"+ma_dict.printVal(ma_dict.get(toks[i])));

					writer.newLine();
				}
				StdOut.println("Line "+(++count) +" is written...");
			}			
			if (writer!=null) {
				writer.flush();
				writer.close();
			}
			if (reader!=null) reader.close();
			StdOut.println("Task finished...");
			
			
		}
		else if (command.equalsIgnoreCase("stemming"))
		{
			AssasBand assas = new AssasBand();
			int count = 0;
			for (String line; (line = reader.readLine()) != null;) 
			{
				line = line.trim();

				if (line.length()==0) continue;
				String toks[] = line.split("[ \t]+");//\\s
				for(int i=0; i<toks.length;i++)
				{
					if ((toks.length-1)==i)
					{
						writer.write(assas.applyStemming(toks[i]));
						writer.newLine();
						continue;
					}
					writer.write(assas.applyStemming(toks[i])+" ");
				}
				StdOut.println("Line "+(++count) +" is written...");
			}			
			if (writer!=null) {
				writer.flush();
				writer.close();
			}
			if (reader!=null) reader.close();
			StdOut.println("Task finished...");
		
		}
		else if (command.equalsIgnoreCase("tagging"))
		{
			POS_tagger pos = new POS_tagger();
			
			HashMap<String, String> dict1 = pos.initialize_unigram("data/unigram_stats.txt");
			HashMap<String, Bigram_Tags> dict2 = pos.initialize_bigram("data/bigram_stats.txt", 200000);
			
			int count = 0;
			for (String line; (line = reader.readLine()) != null;) 
			{
				if (line.length()==0) continue;
				String toks[] = line.split("[ ]+");//\\s
				for(int i=0; i<toks.length;i++)
				{
					for(int j=i+1; j<toks.length;)
					{
						String w1 = toks[i];
						String w2 = toks[j];
						String bi = w1+w2;
						
						Bigram_Tags bt = dict2.get(bi);
						if (bt==null) 
						{
							String ut = dict1.get(w1);
							if (ut==null)
								writer.write(w1+"|UNK ");
							else 
								writer.write(w1+"|"+ut+" ");
							
							
						}
						else 
						{
							writer.write(w1+"|"+bt.getTag1()+" ");
						}

						break;
					}
					if((toks.length-1)==i) 
					{
						String w1 = toks[i];
						if (w1.equals("۔") || w1.equals("؟")||w1.equals(":") ) 
							writer.write(w1+"|SM"); 
						else 
						{
							String ut = dict1.get(w1);
							if (ut==null)
								writer.write(w1+"|UNK");
							else 
								writer.write(w1+"|"+ut);
						}
						writer.newLine();
					}
				}
				StdOut.println("Line "+(++count) +" is written...");
			}			
			if (writer!=null) {
				writer.flush();
				writer.close();
			}
			if (reader!=null) reader.close();
			StdOut.println("Task finished...");
			
		}
		else 
		{
			StdOut.println(err_message);
			System.exit(0);
		}
		
	}

}
