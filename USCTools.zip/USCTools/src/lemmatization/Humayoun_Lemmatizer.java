package lemmatization;

import java.util.ArrayList;
import java.util.HashMap;

import utils.DHashMap;
import utils.StdOut;
import utils.Utils;


public class Humayoun_Lemmatizer {


	public static void main(String[] args) throws Exception
	{
		Humayoun_Lemmatizer hum = new Humayoun_Lemmatizer();
		HashMap<String, String> lemma_dict = hum.initialize_dict_lemma("data/urdu_unicode.fullform.txt");
		
		//key is name
		StdOut.println("طوطے\t"+lemma_dict.get("طوطے"));

		
		DHashMap<String, String> ma_dict = hum.initialize_MA("data/urdu_unicode.fullform.txt");
		StdOut.println("طوطے\t"+ma_dict.printVal(ma_dict.get("طوطے")));
		
		
		//old versions. Slow
		String analysis = hum.applyHumayoun_MA("چیرتی");
		StdOut.println(analysis);
		
		String stem = hum.applyHumayoun_Lemmatizer("چیرتی");
		StdOut.println(stem);
		
		
		/*
		 stem = hum.applyUltraStemmer_FIX("چیرتی", 2) ;
		System.out.println(stem);
		
		stem = hum.applyUltraStemmer_FIX_special("چیرتی", 2) ;
		System.out.println(stem);
		*/
		
		
	}
	
	public HashMap<String, String> initialize_dict_lemma(String sourcefile) throws Exception
	{
		Utils u = new Utils();
		ArrayList<String> lemmaList = u.read_as_list(sourcefile);
		HashMap<String, String> dict = new HashMap<String, String>();
		
		for(int i=0; i<lemmaList.size(); i++)
		{
			String line = lemmaList.get(i);
			String toks[] = line.split("[ ]+");
			if (toks.length == 0) continue;
			dict.put(toks[0].trim(), toks[2].trim());
			//StdOut.println(toks[0].trim() +"\t"+ toks[2].trim());
		}

		return dict;
	}
	
	public DHashMap<String, String> initialize_MA(String sourcefile) throws Exception
	{
		Utils u = new Utils();
		ArrayList<String> lemmaList = u.read_as_list(sourcefile);
		DHashMap<String, String> dict_ma = new DHashMap<String, String>();
		
		for(int i=0; i<lemmaList.size(); i++)
		{
			
			String line = lemmaList.get(i).replaceAll("\\(0\\)", "").replaceAll("-", "");
			
			String toks[] = line.split("[ ]+");
			if (toks.length == 0) continue;

			String output = toks[2].trim();
			for(int x=5; x<toks.length; x++)
			{
				output = output + " " + toks[x].trim();
			}
			
			dict_ma.put(toks[0].trim(), output);
		}
		
		return dict_ma;
		
	}
	
	
	public String applyHumayoun_MA(String surfaceform) throws Exception
	{
		Utils u = new Utils();
		String analysis = "";
		boolean found = false;

		String filename= "data/urdu_unicode.fullform.txt";
		
		ArrayList<String> lemmaList = u.read_as_list(filename);
		int count=0;
		for(int i=0; i<lemmaList.size(); i++)
		{
			String line = lemmaList.get(i).replaceAll("\\(0\\)", "").replaceAll("-", "");
			String dict[] = line.split("[ ]+");
			if (dict.length == 0) break;
			
			if (surfaceform.startsWith(dict[0]))
			{
				if (surfaceform.equals(dict[0]))
				{
					String output="";
					if (count==0){
						output = dict[0].trim() + " \t " + dict[2].trim();
						count=1;
					}
					else{
						output = " \t   " ;
					}
					
					
					for(int x=5; x<dict.length; x++)
					{
						output = output + " " + dict[x].trim();
						
						if (x==dict.length-1) output = output+"\n";
					}
					//StdOut.print(output);
					analysis = analysis+output;
					found = true;
					//break;
				}
			}
			
		}
		
		if (surfaceform.equals("۔") ) {
			analysis = surfaceform + " \n";
			found = true;
		}
		else if (surfaceform.equals("؟") ) {
			analysis = surfaceform + " \n";
			found = true;
		}
		else if (surfaceform.equals(":") ) {
			analysis = surfaceform + " \n";
			found = true;
		} 
		else if (surfaceform.equals("،") ){
			analysis = surfaceform + " \n";
			found = true;
		}
			
		if (!found) analysis = surfaceform +" NOT_FOUND\n";
		
		return analysis;
	}
	
	public String applyHumayoun_Lemmatizer(String surfaceform) throws Exception
	{
		Utils u = new Utils();
		String rootform = "";
		
		String filename = "data/urdu_unicode.fullform.txt" ;
		
		//TableLookup stemmer file
		ArrayList<String> lemmaList = u.read_as_list(filename);
		
		rootform = surfaceform;
		
		if (surfaceform.equals("۔") || surfaceform.equals("؟") || surfaceform.equals(":") || surfaceform.equals("،"))
		{
			return surfaceform ;
		}
		for(int i=0; i<lemmaList.size(); i++)//
		{
			String line = lemmaList.get(i);
			String dict[] = line.split("[: ]+");

			if (dict.length == 0) break;

			if (surfaceform.startsWith(dict[0]))
			{
				if (surfaceform.equals(dict[0]))
				{
					rootform = dict[1]; 
					//System.out.println(dict[0]+"			"+dict[1]);
					break;
				}
			}
		}

		return rootform;
	}
		
	public String applyUltraStemmer_FIX(String surfaceform, int i) throws Exception
	{
		if (surfaceform.equals("۔")) return "۔";
		if (surfaceform.length()<i) return surfaceform;
		String stemform = surfaceform.substring(0, i);
		
		return stemform;
	}
	
	public String applyUltraStemmer_FIX_special(String surfaceform, int i) throws Exception
	{
		if (surfaceform.length()==0) return "";
		if (surfaceform.equals("۔")) return "۔";
		if (surfaceform.length()<i) return "";
		String stemform = surfaceform.substring(0, i);
		
		return stemform;
	}
	
	

}
